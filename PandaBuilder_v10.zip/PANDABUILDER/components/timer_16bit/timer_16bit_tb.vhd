--**************************************************************************
--* FILE      :   timer_16bit_tb.vhd		                          	  			*
--* PROJECT   :   PANDA BUILDER                    							  	*
--*                                                                       	*
--* VERSION   DATE	     PROGRAMMER	      REMARKS                      	*
--* 1.0       22.08.2008  Br�ndler Oliver    File written              	  	*
--*                                                                       	*
--* USED BY                                                               	*
--* Logic Solutions Br�ndler					                                	*
--*                                                                       	*
--* INTRODUCTION                                                          	*
--* Testbench for tmr_8bit.vhd
--*                                                                       	*
--* COPYRIGHT (C) 2008  by Logic Solutions Br�ndler CH-6043 Adligenswil   	*
--**************************************************************************

----------------------------------------------------------------------------
--  Libraries
----------------------------------------------------------------------------
LIBRARY ieee;
	USE ieee.std_logic_1164.all;
	USE ieee.numeric_std.all;

----------------------------------------------------------------------------
--  Entity
----------------------------------------------------------------------------
ENTITY timer_16bit_tb IS
END ENTITY timer_16bit_tb;

----------------------------------------------------------------------------
--  Architecture
----------------------------------------------------------------------------
ARCHITECTURE rtl OF timer_16bit_tb IS
	SIGNAL clk, res_n, cs, wr, rd, int : std_logic;
	SIGNAL adr : std_logic_vector(2 DOWNTO 0);
	SIGNAL din, dout : std_logic_vector(7 DOWNTO 0);
	
	PROCEDURE write_reg(	CONSTANT reg	: IN	std_logic_vector(2 DOWNTO 0);
								CONSTANT val	: IN	std_logic_vector(7 DOWNTO 0);
								SIGNAL 	adr	: OUT	std_logic_vector(2 DOWNTO 0);
								SIGNAL 	cs		: OUT	std_logic;
								SIGNAL 	wr		: OUT	std_logic;
								SIGNAL 	din	: OUT	std_logic_vector(7 DOWNTO 0)) IS
	BEGIN
		cs <= '1';
		wr <= '1';
		din <= val;
		adr <= reg;
		WAIT FOR 100 ns;
		wr <= '0';
		WAIT FOR 100 ns;
		cs <= '0';	
	END PROCEDURE;
	
	PROCEDURE read_reg(	CONSTANT reg	: IN	std_logic_vector(2 DOWNTO 0);
								CONSTANT val	: IN	std_logic_vector(7 DOWNTO 0);
								SIGNAL 	adr	: OUT	std_logic_vector(2 DOWNTO 0);
								SIGNAL 	cs		: OUT	std_logic;
								SIGNAL 	rd		: OUT	std_logic;
								SIGNAL 	dout	: IN	std_logic_vector(7 DOWNTO 0)) IS
	BEGIN
		cs <= '1';
		rd <= '1';
		adr <= reg;
		WAIT FOR 100 ns;
		rd <= '0';
		WAIT FOR 100 ns;
		cs <= '0';	
		ASSERT val = dout REPORT "Read unexpected Value from Register" SEVERITY error;
	END PROCEDURE;
	
	CONSTANT TMRL_REG : std_logic_vector(2 DOWNTO 0) := "000";
	CONSTANT TMRH_REG : std_logic_vector(2 DOWNTO 0) := "001";
	CONSTANT RLDL_REG : std_logic_vector(2 DOWNTO 0) := "010";
	CONSTANT RLDH_REG : std_logic_vector(2 DOWNTO 0) := "011";
	CONSTANT SHAD_REG : std_logic_vector(2 DOWNTO 0) := "100";
	CONSTANT CFG_REG 	: std_logic_vector(2 DOWNTO 0) := "101";
	CONSTANT UPDOWN 	: std_logic_vector(7 DOWNTO 0) := X"08";
	CONSTANT RELOAD 	: std_logic_vector(7 DOWNTO 0) := X"04";
	CONSTANT RUN 		: std_logic_vector(7 DOWNTO 0) := X"02";
	CONSTANT INTON 	: std_logic_vector(7 DOWNTO 0) := X"01";
	CONSTANT INT_REG 	: std_logic_vector(2 DOWNTO 0) := "110";
	
BEGIN

I1 : entity work.timer_16bit
GENERIC MAP (
	clk_frequency => 10000000,
	resolution_us => 5
)
PORT MAP (
	clk => clk,
	res_n => res_n,
	cs => cs,
	adr => adr,
	din => din,
	dout => dout,
	wr => wr,
	rd => rd,
	int => int
);

do_clk : PROCESS
BEGIN	
	clk <= '1';
	WAIT FOR 50 ns;
	clk <= '0';
	WAIT FOR 50 ns;
END PROCESS do_clk;

do_res_n : PROCESS
BEGIN
	res_n <= '0';
	WAIT FOR 200 ns;
	res_n <= '1';
	WAIT;
END PROCESS;

do_test : PROCESS
BEGIN
	-- Wait for Reset
	WAIT FOR 500 ns;
	
	-- Test Timer Stopped
	ASSERT false REPORT "Test Timer Stopped" SEVERITY note;
	write_reg(CFG_REG, UPDOWN, adr, cs, wr, din);
	WAIT FOR 5.5 us;
	read_reg(SHAD_REG, X"00", adr, cs, rd, dout);
	read_reg(TMRL_REG, X"00", adr, cs, rd, dout);
	
	-- Test no read without shadow register
	ASSERT false REPORT "Test no read without Shadow Register" SEVERITY note;
	write_reg(CFG_REG, (UPDOWN OR RUN), adr, cs, wr, din);
	WAIT FOR 20.5 us;
	read_reg(TMRL_REG, X"00", adr, cs, rd, dout);
	
	-- Test Correct Resolution
	ASSERT false REPORT "Test Correct Resolution" SEVERITY note;
	read_reg(SHAD_REG, X"00", adr, cs, rd, dout);
	read_reg(TMRL_REG, X"04", adr, cs, rd, dout);
	
	-- Test no write without shadow register
	ASSERT false REPORT "Test no write without Shadow Register" SEVERITY note;
	write_reg(TMRH_REG, X"0F", adr, cs, wr, din);
	read_reg(SHAD_REG, X"00", adr, cs, rd, dout);
	read_reg(TMRH_REG, X"00", adr, cs, rd, dout);
	
	-- Test Overflow without Interrupt
	ASSERT false REPORT "Test Overflow without Interrupt, without Reload" SEVERITY note;
	write_reg(CFG_REG, X"00", adr, cs, wr, din);
	write_reg(TMRL_REG, X"FD", adr, cs, wr, din);
	write_reg(TMRH_REG, X"FF", adr, cs, wr, din);
	write_reg(SHAD_REG, X"00", adr, cs, wr, din);
	write_reg(CFG_REG, (RUN OR UPDOWN), adr, cs, wr, din);
	WAIT FOR 15.5 us;
	ASSERT int = '0' REPORT "Unexpected Interrupt" SEVERITY error;
	read_reg(SHAD_REG, X"00", adr, cs, rd, dout);
	read_reg(TMRL_REG, X"00", adr, cs, rd, dout);
	read_reg(TMRH_REG, X"00", adr, cs, rd, dout);
	read_reg(INT_REG, X"01", adr, cs, rd, dout);
	
	-- Test Clear Interrupt
	ASSERT false REPORT "Test Interrupt Clear" SEVERITY note;
	write_reg(INT_REG, X"00", adr, cs, wr, din);
	read_reg(INT_REG, X"00", adr, cs, rd, dout);
	
	-- Test Auto Relaod and Interrupt
	ASSERT false REPORT "Test Interrupt and Auto Reload" SEVERITY note;
	write_reg(RLDL_REG, X"55", adr, cs, wr, din);
	write_reg(RLDH_REG, X"55", adr, cs, wr, din);
	write_reg(CFG_REG, (RELOAD OR RUN OR INTON), adr, cs, wr, din);
	write_reg(TMRL_REG, X"02", adr, cs, wr, din);
	write_reg(TMRH_REG, X"00", adr, cs, wr, din);
	write_reg(SHAD_REG, X"00", adr, cs, wr, din);
	WAIT FOR 15.5 us;
	ASSERT int = '1' REPORT "Interrupt was not triggered" SEVERITY error;
	write_reg(INT_REG, X"00", adr, cs, wr, din);
	ASSERT int = '0' REPORT "Interrupt was not cleared" SEVERITY error; 
	read_reg(SHAD_REG, X"00", adr, cs, rd, dout);
	read_reg(TMRH_REG, X"55", adr, cs, rd, dout);
	read_reg(TMRL_REG, X"55", adr, cs, rd, dout);
	WAIT;
	
END PROCESS;

END ARCHITECTURE rtl;
