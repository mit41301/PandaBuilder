
Please have a look at the user guide:
DOCUMENTS/PandaBuilder_UserGuide.pdf